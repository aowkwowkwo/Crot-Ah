#!/bin/bash

# Update and upgrade packages
yes | pkg update
yes | pkg upgrade

# Install basic packages
yes | pkg install python
yes | pkg install python2
yes | pkg install python3
yes | pkg install git
yes | pkg install zip
yes | pkg install npm
yes | pkg install unzip
yes | pkg install curl
yes | pkg install perl
yes | pkg install toilet
yes | pkg install gatling
yes | pkg install micro
yes | pkg install nano
yes | pkg install vim
yes | pkg install clang
yes | pkg install bash
yes | pkg install figlet
yes | pkg install php
yes | pkg install clang
yes | pkg install zsh
yes | pkg install termux-api
yes | pkg install termux-tools
yes | pkg install wget
yes | pkg install cowsay
yes | pkg install openssh
yes | pkg install openssl
yes | pkg install ffmpeg
yes | pkg install parallel
yes | pkg install nodejs
yes | pkg install tor
yes | pkg install man
yes | pkg install neofetch
yes | pkg install sl
yes | pkg install swift
yes | pkg install lua
yes | pkg install nmap
yes | pkg install tar
yes | pkg install cmatrix
yes | pkg install chroot
yes | pkg install ruby
yes | pkg install fish
yes | pkg install golang
yes | pkg install gatling
yes | pkg install python-pip

# Install Python modules
yes | pip install requests
yes | pip2 install requests
yes | pip3 install requests
yes | pip install mechanize
yes | pip2 install mechanize
yes | pip3 install mechanize
yes | pip install wget
yes | pip2 install wget
yes | pip3 install wget
yes | pip install wheel
yes | pip2 install wheel
yes | pip3 install wheel
yes | pip install lolcat
yes | pip2 install lolcat
yes | pip3 install lolcat
yes | pip install futures
yes | pip2 install futures
yes | pip3 install futures
yes | pip install rich
yes | pip2 install rich
yes | pip3 install rich
yes | pip install npm
yes | pip2 install npm
yes | pip3 install npm
yes | pip install bs4
yes | pip2 install bs4
yes | pip3 install bs4
yes | pip install so
yes | pip2 install so
yes | pip3 install so
yes | pip install uuid
yes | pip2 install uuid
yes | pip3 install uuid
yes | pip install colorama
yes | pip2 install colorama
yes | pip3 install colorama
yes | pip install sockets
yes | pip2 install sockets
yes | pip3 install sockets
yes | pip install pysocks
yes | pip2 install pysocks
yes | pip3 install pysocks
yes | pip install threaded
yes | pip2 install threaded
yes | pip3 install threaded
yes | pip install regex
yes | pip2 install regex
yes | pip3 install regex
yes | pip install random
yes | pip2 install random
yes | pip3 install random
yes | pip install wordlist
yes | pip2 install wordlist
yes | pip3 install wordlist
yes | pip install requirements.txt
yes | pip freeze > requirements.txt
yes | pip install -r requirements.txt
yes | pip2 install -r requirements.txt
yes | pip3 install -r requirements.txt
yes | pip install module-name
yes | pip3 install module-name
yes | pip install flask
yes | pip2 install flask
yes | pip3 install flask
yes | pip install --upgrade pip
yes | pip2 install --upgrade pip

# Setup storage and other tools
yes | termux-setup-storage
