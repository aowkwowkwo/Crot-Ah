#!/bin/bash

green='\e[1;32m'
tosca='\e[1;36m'
reset='\e[0m'

function show_banner() {
    clear
    echo -e "${green}██╗███╗   ██╗███████╗███████╗██████╗ ███╗   ██╗ █████╗ ██╗       █████╗  ${tosca}██╗   ██╗██████╗ ██╗ ██████╗"
    echo -e "${green}██║████╗  ██║██╔════╝██╔════╝██╔══██╗████╗  ██║██╔══██╗██║      ██╔══██╗ ${tosca}██║   ██║██╔══██╗██║██╔═══██╗"
    echo -e "${green}██║██╔██╗ ██║█████╗  █████╗  ██████╔╝██╔██╗ ██║███████║██║█████╗███████║ ${tosca}██║   ██║██║  ██║██║██║   ██║"
    echo -e "${green}██║██║╚██╗██║██╔══╝  ██╔══╝  ██╔══██╗██║╚██╗██║██╔══██║██║╚════╝██╔══██║ ${tosca}██║   ██║██║  ██║██║██║   ██║"
    echo -e "${green}██║██║ ╚████║██║     ███████╗██║  ██║██║ ╚████║██║  ██║███████╗ ██║  ██║ ${tosca}╚██████╔╝██████╔╝██║╚██████╔╝"
    echo -e "${green}╚═╝╚═╝  ╚═══╝╚═╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝ ╚═╝  ╚═╝ ${tosca} ╚═════╝ ╚═════╝ ╚═╝ ╚═════╝${reset}"
    echo ""
}

while true; do
    show_banner
    echo -ne "${tosca}Masukkan link YouTube / Spotify / MP3 / MP4: ${reset}"
    read link
    echo -e "${green}Memutar lagu...${reset}"
    mpv "$link"

    echo -e "\n${tosca}Lagu selesai diputar.${reset}"
    echo -e "${green}[1]${reset} Putar lagi"
    echo -e "${green}[2]${reset} Keluar"
    echo -ne "${tosca}Pilih opsi: ${reset}"
    read opsi

    if [[ "$opsi" != "1" ]]; then
        echo -e "${green}Keluar...${reset}"
        exit
    fi
done
