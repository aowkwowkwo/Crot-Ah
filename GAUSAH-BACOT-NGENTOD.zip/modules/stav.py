import os
import shutil
import subprocess

# Warna terminal
GREEN = '\033[0;32m'
CYAN = '\033[0;36m'
WHITE = '\033[0;37m'
NC = '\033[0m'  # No Color

# Function untuk konversi ukuran file ke format yang lebih mudah dibaca (GB, MB)
def human_readable(size):
    if size < 1024 * 1024:
        return f"{size // 1024}MB"
    else:
        return f"{size // (1024 * 1024)}GB"

# Tampilkan banner
def print_banner():
    os.system('clear')
    print(f"{CYAN}╔════════════════════════════════════════╗")
    print(f"║         InfernalXploit Cleaner          ║")
    print(f"╠════════════════════════════════════════╣")
    print(f"║     Menghapus Semua Cache Termux        ║")
    print(f"╚════════════════════════════════════════╝")
    print(f"{NC}")

# Tampilkan info sebelum pembersihan
def show_before_cleanup():
    print(f"{CYAN}[INFO]{NC} Memori Termux sebelum pembersihan:")
    
    # Dapatkan info memori dan tampilkan dalam GB, MB
    mem_info = subprocess.check_output("free -h", shell=True).decode().strip().split('\n')[1]
    total, used, free = mem_info.split()[1:4]
    total_gb = total.replace('Gi', 'GB').replace('Mi', 'MB')
    used_gb = used.replace('Gi', 'GB').replace('Mi', 'MB')
    free_gb = free.replace('Gi', 'GB').replace('Mi', 'MB')
    print(f"Total Memori: {total_gb}, Digunakan: {used_gb}, Tersedia: {free_gb}")
    print()

    print(f"{CYAN}[INFO]{NC} Ukuran cache ~/.cache:")
    cache1 = get_folder_size(os.path.expanduser("~/.cache"))
    print(f"{human_readable(cache1)}\n")

    print(f"{CYAN}[INFO]{NC} Ukuran cache /data/data/com.termux/cache:")
    cache2 = get_folder_size("/data/data/com.termux/cache")
    print(f"{human_readable(cache2)}\n")

# Mengambil ukuran folder
def get_folder_size(folder):
    total = 0
    for dirpath, dirnames, filenames in os.walk(folder):
        for filename in filenames:
            file_path = os.path.join(dirpath, filename)
            total += os.path.getsize(file_path)
    return total

# Menghapus cache dan file sampah
def clean_cache():
    print(f"{GREEN}[+] {NC}Menghapus cache di ~/.cache ...")
    shutil.rmtree(os.path.expanduser("~/.cache"), ignore_errors=True)

    print(f"{GREEN}[+] {NC}Menghapus cache di /data/data/com.termux/cache ...")
    shutil.rmtree("/data/data/com.termux/cache", ignore_errors=True)

    print(f"{GREEN}[+] {NC}Menghapus semua __pycache__ ...")
    for root, dirs, files in os.walk(os.path.expanduser("~")):
        if "__pycache__" in dirs:
            shutil.rmtree(os.path.join(root, "__pycache__"), ignore_errors=True)

    print(f"{GREEN}[+] {NC}Menghapus file sampah (*.pyc, *.pyo) ...")
    for root, dirs, files in os.walk(os.path.expanduser("~")):
        for file in files:
            if file.endswith(".pyc") or file.endswith(".pyo"):
                os.remove(os.path.join(root, file))

    # Menghapus cache dari package manager Termux (safe)
    print(f"{GREEN}[+] {NC}Membersihkan cache package manager ...")
    subprocess.run("pkg clean", shell=True)

# Tampilkan info setelah pembersihan
def show_after_cleanup():
    print(f"{CYAN}[INFO]{NC} Memori Termux setelah pembersihan:")
    
    # Dapatkan info memori dan tampilkan dalam GB, MB
    mem_info = subprocess.check_output("free -h", shell=True).decode().strip().split('\n')[1]
    total, used, free = mem_info.split()[1:4]
    total_gb = total.replace('Gi', 'GB').replace('Mi', 'MB')
    used_gb = used.replace('Gi', 'GB').replace('Mi', 'MB')
    free_gb = free.replace('Gi', 'GB').replace('Mi', 'MB')
    print(f"Total Memori: {total_gb}, Digunakan: {used_gb}, Tersedia: {free_gb}")
    print()

    print(f"{CYAN}[INFO]{NC} Ukuran cache ~/.cache sekarang:")
    cache1 = get_folder_size(os.path.expanduser("~/.cache"))
    print(f"{human_readable(cache1)}\n")

    print(f"{CYAN}[INFO]{NC} Ukuran cache /data/data/com.termux/cache sekarang:")
    cache2 = get_folder_size("/data/data/com.termux/cache")
    print(f"{human_readable(cache2)}\n")

    print(f"{GREEN}[✓] {NC}Pembersihan cache selesai dengan aman!")

# Main function
def main():
    print_banner()
    show_before_cleanup()
    input(f"{CYAN}[?]{NC} Tekan ENTER untuk mulai membersihkan semua cache ...")
    clean_cache()
    show_after_cleanup()

if __name__ == "__main__":
    main()
