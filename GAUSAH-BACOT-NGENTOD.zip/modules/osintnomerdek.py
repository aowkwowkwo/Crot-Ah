import os
import subprocess
from colorama import Fore, Style, init

init(autoreset=True)  # Auto-reset warna setiap print

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def banner():
    print(Fore.CYAN + Style.BRIGHT + "=== InfernalXploit Osint===")
    print(Fore.RED + "[1] " + Fore.WHITE + "Cek App")
    print(Fore.RED + "[2] " + Fore.WHITE + "Cek E-wallet")
    print(Fore.RED + "[3] " + Fore.WHITE + "Cek Bank")
    print(Fore.RED + "[4] " + Fore.WHITE + "Keluar")

def main():
    while True:
        clear()
        banner()
        pilihan = input(Fore.CYAN + "\nPilih menu (1-4): " + Fore.WHITE).strip()

        if pilihan == '1':
            nomor = input(Fore.YELLOW + "Masukkan nomor HP (087xxxx): " + Fore.WHITE).strip()
            subprocess.run(["python", "modules/hunternum.py", "-app", nomor])
        elif pilihan == '2':
            nomor = input(Fore.YELLOW + "Masukkan nomor e-wallet (08xxxx): " + Fore.WHITE).strip()
            subprocess.run(["python", "modules/hunternum.py", "-w", nomor])
        elif pilihan == '3':
            nomor = input(Fore.YELLOW + "Masukkan nomor rekening bank (06xxxx): " + Fore.WHITE).strip()
            subprocess.run(["python", "modules/hunternum.py", "-b", nomor])
        elif pilihan == '4':
            print(Fore.GREEN + "\nKeluar...")
            break
        else:
            print(Fore.RED + "Pilihan tidak valid!")

        input(Fore.CYAN + "\nTekan ENTER untuk kembali ke menu...")

if __name__ == "__main__":
    main()
