#!/bin/bash

# Warna
RED='\033[0;31m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # Reset warna

# Membersihkan layar
clear

# Menampilkan banner
echo -e "${CYAN}=============================="
echo -e "${RED}INFERNALXPLOIT TRACK FOTO      "
echo -e "${CYAN}==============================${NC}"

# Menampilkan menu
echo -e "${WHITE}1. ${CYAN}OPEN TRACK FOTO"
echo -e "${WHITE}2. ${CYAN}Exit${NC}"
echo -ne "${WHITE}Pilih opsi: ${NC}"
read pilihan

if [ "$pilihan" == "1" ]; then
    xdg-open "https://exif.tools/"
elif [ "$pilihan" == "2" ]; then
    echo -e "${RED}Keluar...${NC}"
    exit
else
    echo -e "${RED}Pilihan tidak valid!${NC}"
fi
